import streamlit as st
import numpy as np
import pandas as pd
from PIL import Image
import joblib
import os
import torch
import torch.nn as nn
from torchvision import models, transforms
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
import zipfile
from huggingface_hub import hf_hub_download

st.set_page_config(
    page_title="Fashion Recommendation System",
    layout="wide"
)

# Elegant Editorial Light Theme
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700&family=Inter:wght@300;400;500;600&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
        color: #2B2620;
    }

    .stApp {
        background: #FAF7F2;
    }

    h1 {
        font-family: 'Playfair Display', serif !important;
        font-weight: 600 !important;
        letter-spacing: 0.3px;
        color: #211D18 !important;
        margin-bottom: 0 !important;
    }

    .hero-subtitle {
        text-align: center;
        color: #8A7F6E;
        font-size: 1rem;
        font-weight: 400;
        letter-spacing: 0.3px;
        margin-top: 0.5rem;
        margin-bottom: 2.5rem;
    }

    h2, h3 {
        font-family: 'Playfair Display', serif !important;
        font-weight: 600 !important;
        color: #211D18 !important;
        letter-spacing: 0.2px;
    }

    section[data-testid="stSidebar"] {
        background: #F1ECE3;
        border-right: 1px solid #E3DACB;
    }
    section[data-testid="stSidebar"] h1 {
        font-size: 1.3rem !important;
    }

    div[data-testid="stImage"] {
        background: #FFFFFF;
        border: 1px solid #E8E1D5;
        border-radius: 10px;
        padding: 14px;
        box-shadow: 0 1px 3px rgba(43, 38, 32, 0.05);
        transition: border-color 0.25s ease, box-shadow 0.25s ease, transform 0.2s ease;
    }
    div[data-testid="stImage"]:hover {
        border-color: #B08D57;
        box-shadow: 0 6px 18px rgba(176, 141, 87, 0.15);
        transform: translateY(-2px);
    }
    div[data-testid="stImage"] img {
        border-radius: 6px;
        image-rendering: -webkit-optimize-contrast;
        image-rendering: crisp-edges;
    }

    .stButton>button {
        background: #211D18;
        color: #FAF7F2;
        font-weight: 500;
        font-family: 'Inter', sans-serif;
        border-radius: 6px;
        padding: 0.5rem 1.6rem;
        border: 1px solid #211D18;
        letter-spacing: 0.4px;
        font-size: 0.85rem;
        transition: all 0.2s ease;
    }
    .stButton>button:hover {
        background: #B08D57;
        border-color: #B08D57;
        color: #FFFFFF;
    }

    div[role="radiogroup"] label {
        background: #FFFFFF;
        border: 1px solid #E8E1D5;
        border-radius: 8px;
        padding: 0.5rem 0.8rem !important;
        margin-bottom: 0.4rem;
        transition: all 0.2s ease;
    }
    div[role="radiogroup"] label:hover {
        border-color: #B08D57;
    }

    [data-testid="stMetric"] {
        background: #FFFFFF;
        border: 1px solid #E8E1D5;
        border-top: 3px solid #B08D57;
        border-radius: 10px;
        padding: 1.1rem;
    }
    [data-testid="stMetricValue"] {
        color: #211D18 !important;
        font-family: 'Playfair Display', serif !important;
    }

    div[data-testid="stSlider"] div[role="slider"] {
        background-color: #B08D57 !important;
    }

    hr {
        border-color: #E3DACB;
        margin: 1.5rem 0;
    }

    .stCaption, [data-testid="stCaptionContainer"] {
        color: #8A7F6E !important;
    }

    div[data-testid="stAlert"] {
        background: #FFFFFF;
        border-radius: 8px;
        border: 1px solid #E8E1D5;
    }

    ::-webkit-scrollbar { width: 10px; }
    ::-webkit-scrollbar-track { background: #F1ECE3; }
    ::-webkit-scrollbar-thumb {
        background: #C9BBA0;
        border-radius: 10px;
    }
</style>
""", unsafe_allow_html=True)

# Hugging Face Configuration
HF_REPO_ID = "kashish8326/myntra-dataset"
HF_FILENAME = "myntradataset.zip"
HF_REPO_TYPE = "model"  # file currently lives in the model repo, not the dataset repo


@st.cache_resource
def setup_dataset():
    """
    Downloads and extracts the dataset from Hugging Face Hub (only on first run).
    Returns the path to the extracted dataset folder.
    """
    # Anchor to the script's own directory, not the ambiguous process
    # working directory -- this differs between local runs and Streamlit
    # Cloud and is the likely cause of "folder missing" after extraction.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_folder = os.path.join(base_dir, "myntradataset")

    # Check if dataset already exists
    if os.path.exists(dataset_folder) and os.path.exists(os.path.join(dataset_folder, "images")):
        st.sidebar.info("✅ Dataset already loaded")
        return dataset_folder

    try:
        with st.spinner("📥 Downloading dataset from Hugging Face..."):
            zip_path = hf_hub_download(
                repo_id=HF_REPO_ID,
                filename=HF_FILENAME,
                repo_type=HF_REPO_TYPE
            )

        with st.spinner("📂 Extracting dataset..."):
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                names = zip_ref.namelist()
                st.sidebar.write("Zip top entries:", names[:8])

                # This zip was created on Windows, so entries use backslashes
                # (e.g. "myntradataset\\images\\10000.jpg"). On Linux those
                # are just literal characters, not path separators, so
                # extractall() creates one flat mangled-name file instead of
                # a real nested folder. Extract manually, normalizing '\' to
                # '/' for every entry so it works the same on both OSes.
                for entry in names:
                    normalized = entry.replace('\\', '/')
                    target_path = os.path.join(base_dir, *normalized.split('/'))

                    if normalized.endswith('/'):
                        os.makedirs(target_path, exist_ok=True)
                        continue

                    os.makedirs(os.path.dirname(target_path), exist_ok=True)
                    with zip_ref.open(entry) as source, open(target_path, 'wb') as target:
                        target.write(source.read())

        st.sidebar.write("base_dir:", base_dir)
        st.sidebar.write("base_dir contents:", os.listdir(base_dir))
        st.sidebar.write(
            "Extracted contents:",
            os.listdir(dataset_folder) if os.path.exists(dataset_folder) else "folder missing"
        )

        st.sidebar.success("✅ Dataset ready!")
    except Exception as e:
        st.error(f"❌ Error setting up dataset: {str(e)}")
        st.info("💡 Double check the repo_id, filename, and repo_type are correct.")
        st.stop()

    # Verify dataset structure
    images_dir = os.path.join(dataset_folder, "images")
    if os.path.exists(images_dir):
        image_count = len([f for f in os.listdir(images_dir) if f.endswith(('.jpg', '.jpeg', '.png'))])
        st.sidebar.success(f"✅ Dataset ready! {image_count:,} images found")
    else:
        st.sidebar.warning("⚠️ Dataset structure might be incorrect. Expected: myntradataset/images/")

    return dataset_folder


def load_sharp_image(path, target_width=200):
    """
    Loads an image and upscales it using LANCZOS resampling for a
    crisper look. Source images in this dataset are only 60x80px,
    so this cannot add real detail -- it just avoids the extra-blurry
    stretching that Streamlit's default resize produces.
    """
    img = Image.open(path)
    if img.mode != 'RGB':
        img = img.convert('RGB')
    w, h = img.size
    target_height = int(target_width * h / w)
    return img.resize((target_width, target_height), Image.LANCZOS)


class FeatureExtractor:
    def __init__(self, model_name='resnet18'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        if model_name == 'resnet50':
            self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        else:
            self.model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)

        self.model = nn.Sequential(*list(self.model.children())[:-1])
        self.model = self.model.to(self.device)
        self.model.eval()

        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])

    def extract_features(self, image):
        if isinstance(image, str):
            image = Image.open(image)
        elif isinstance(image, np.ndarray):
            image = Image.fromarray(image)

        if image.mode != 'RGB':
            image = image.convert('RGB')

        image_tensor = self.transform(image).unsqueeze(0).to(self.device)

        with torch.no_grad():
            features = self.model(image_tensor)

        return features.squeeze().cpu().numpy()


class FashionRecommender:
    def __init__(self, features, metadata_df):
        self.features = features
        self.metadata = metadata_df

        self.knn_model = NearestNeighbors(
            n_neighbors=min(20, len(features)),
            metric='cosine',
            algorithm='brute'
        )
        self.knn_model.fit(features)

    def get_recommendations(self, item_index, n_recommendations=6):
        query_features = self.features[item_index].reshape(1, -1)
        distances, indices = self.knn_model.kneighbors(query_features, n_neighbors=n_recommendations+1)

        indices = indices[0][1:]
        distances = distances[0][1:]

        recommendations = self.metadata.iloc[indices].copy()
        recommendations['similarity_score'] = 1 - distances

        return recommendations

    def find_similar_to_uploaded(self, uploaded_features, n_recommendations=6):
        uploaded_features = uploaded_features.reshape(1, -1)
        distances, indices = self.knn_model.kneighbors(uploaded_features, n_neighbors=n_recommendations)

        indices = indices[0]
        distances = distances[0]

        recommendations = self.metadata.iloc[indices].copy()
        recommendations['similarity_score'] = 1 - distances

        return recommendations


@st.cache_resource
def load_model():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(base_dir, 'models', 'fashion_recommender.pkl')

    if not os.path.exists(model_path):
        st.error("Model not found! Please train the model first.")
        st.code("python train_myntra_model.py")
        st.stop()

    with open(model_path, 'rb') as f:
        model_data = joblib.load(f)

    features = model_data['features']
    metadata = model_data['metadata']

    # Rebuild image_path from filename to avoid Windows-style paths
    # breaking on Streamlit Cloud's Linux environment
    metadata['image_path'] = metadata['filename'].apply(
        lambda fn: os.path.join(base_dir, "myntradataset", "images", fn)
    )

    st.sidebar.success("Model Loaded!")
    st.sidebar.info(f"Items: {len(metadata):,}")

    recommender = FashionRecommender(features, metadata)
    extractor = FeatureExtractor('resnet18')

    return recommender, extractor, metadata


def browse_catalog_mode(recommender, metadata):
    st.header("Browse Fashion Catalog")

    col1, col2 = st.columns([2, 1])
    with col1:
        st.write(f"**Total Items:** {len(metadata):,}")
    with col2:
        n_recommendations = st.slider("Recommendations", 3, 9, 6)

    st.subheader("Select an Item")

    if 'sample_items' not in st.session_state or st.button("Shuffle"):
        st.session_state.sample_items = metadata.sample(min(10, len(metadata)))

    sample_items = st.session_state.sample_items

    cols = st.columns(5)
    selected_idx = None

    for idx, (_, item) in enumerate(sample_items.iterrows()):
        col = cols[idx % 5]
        with col:
            try:
                img = load_sharp_image(item['image_path'], target_width=95)
                st.image(img, width=95)
                if st.button("Select", key=f"btn_{idx}"):
                    selected_idx = item.name
            except:
                st.write("Error")

    if selected_idx is not None:
        st.markdown("---")
        st.subheader("Recommendations")

        query_item = metadata.iloc[selected_idx]

        col1, col2 = st.columns([1, 2])

        with col1:
            st.markdown("### Query Item")
            try:
                query_img = load_sharp_image(query_item['image_path'], target_width=110)
                st.image(query_img, width=110)
                st.caption(query_item['filename'][:30])
            except:
                st.error("Error loading")

        with col2:
            recommendations = recommender.get_recommendations(selected_idx, n_recommendations)

            if len(recommendations) > 0:
                cols = st.columns(3)
                for idx, (_, rec) in enumerate(recommendations.iterrows()):
                    col = cols[idx % 3]
                    with col:
                        try:
                            rec_img = load_sharp_image(rec['image_path'], target_width=95)
                            st.image(rec_img, width=95)
                            st.write(f"**{rec['similarity_score']:.1%}**")
                            st.caption(rec['filename'][:20])
                        except:
                            st.write("Error")


def upload_image_mode(recommender, extractor, metadata):
    st.header("Upload Your Image")

    uploaded_file = st.file_uploader("Choose an image", type=['jpg', 'jpeg', 'png'])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)

        if image.mode != 'RGB':
            image = image.convert('RGB')

        col1, col2 = st.columns([1, 2])

        with col1:
            st.subheader("Your Image")
            st.image(image, width=280)  # user-uploaded photo, usually high-res already

        with col2:
            st.subheader("Similar Items")
            n_recommendations = st.slider("Results", 3, 12, 6)

            with st.spinner("Analyzing..."):
                features = extractor.extract_features(image)

            recommendations = recommender.find_similar_to_uploaded(features, n_recommendations)

            cols = st.columns(3)
            for idx, (_, rec) in enumerate(recommendations.iterrows()):
                col = cols[idx % 3]
                with col:
                    try:
                        rec_img = load_sharp_image(rec['image_path'], target_width=95)
                        st.image(rec_img, width=95)
                        st.write(f"**{rec['similarity_score']:.1%}**")
                        st.caption(rec['filename'][:25])
                    except:
                        st.write("Error")


def analytics_dashboard(metadata):
    st.header("Dataset Analytics")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Total Items", f"{len(metadata):,}")
    with col2:
        st.metric("Unique Images", len(metadata['image_id'].unique()))
    with col3:
        st.metric("Features", "512D")

    st.markdown("---")
    st.subheader("Sample Images")

    cols = st.columns(6)
    sample_items = metadata.sample(min(12, len(metadata)))

    for idx, (_, item) in enumerate(sample_items.iterrows()):
        col = cols[idx % 6]
        with col:
            try:
                img = load_sharp_image(item['image_path'], target_width=90)
                st.image(img, width=90)
            except:
                pass

    st.markdown("---")
    st.subheader("Dataset Info")
    st.dataframe(metadata.head(20), use_container_width=True)


def main():
    st.markdown('<h1 style="text-align: center;">Fashion Recommendation System</h1>', unsafe_allow_html=True)
    st.markdown('<p class="hero-subtitle">AI-powered visual similarity search, built on ResNet18 embeddings and KNN retrieval</p>', unsafe_allow_html=True)

    # Setup dataset from Hugging Face (downloads on first run only)
    dataset_path = setup_dataset()

    recommender, extractor, metadata = load_model()

    st.sidebar.title("Navigation")
    mode = st.sidebar.radio("Select Mode", ["Browse Catalog", "Upload Image", "Analytics"], label_visibility="collapsed")

    if mode == "Browse Catalog":
        browse_catalog_mode(recommender, metadata)
    elif mode == "Upload Image":
        upload_image_mode(recommender, extractor, metadata)
    else:
        analytics_dashboard(metadata)


if __name__ == "__main__":
    main()
