# 👗 Fashion Recommendation System

A content-based fashion recommender built with a ResNet18 feature extractor and K-Nearest Neighbors similarity search. Browse the catalog to get similar item recommendations, or upload your own photo to find visually similar fashion items.

## 🚀 Live Demo

[Try it here](https://your-app-name.streamlit.app) <!-- update this link after deploying -->

## ✨ Features

- **Browse Catalog** — explore sample items and get instant visual recommendations
- **Upload Image** — upload any photo and find similar items from the dataset
- **Analytics Dashboard** — view dataset stats and sample images

## 🛠️ Tech Stack

- **Streamlit** — web app framework
- **PyTorch / torchvision** — ResNet18 for feature extraction
- **scikit-learn** — K-Nearest Neighbors for similarity search
- **Hugging Face Hub** — dataset hosting and download

## 📦 Dataset

Uses the Myntra Fashion Product dataset (~295MB, ~44k images), hosted on [Hugging Face](https://huggingface.co/kashish8326/myntra-dataset) and downloaded automatically on first run.

## 🧠 How It Works

1. Each product image is passed through a pretrained ResNet18 (ImageNet weights) with the final classification layer removed, producing a 512-dimensional feature vector.
2. A K-Nearest Neighbors model (cosine similarity) indexes all feature vectors.
3. For a query image (selected from the catalog or uploaded), the app finds the closest matches in feature space and displays them ranked by similarity score.

## 🖥️ Run Locally

```bash
git clone https://github.com/kashish836/fashion-recommender.git
cd fashion-recommender
pip install -r requirements.txt
streamlit run fashion_app.py
```

The dataset will download automatically from Hugging Face on first run.

## 📁 Project Structure
```
fashion-recommender/
├── fashion_app.py              # Main Streamlit app
├── models/
│   ├── fashion_recommender.pkl # Trained KNN model + metadata
│   ├── fashion_features.npy    # Precomputed feature vectors
│   └── fashion_metadata.csv    # Item metadata
└── requirements.txt
```

## 🙏 Credits

- Dataset: [Fashion Product Images Dataset](https://www.kaggle.com/datasets/paramaggarwal/fashion-product-images-dataset) by Param Aggarwal on Kaggle
- Pretrained weights: ResNet18 (ImageNet) via [torchvision](https://pytorch.org/vision/stable/models.html)

## 📝 Notes

- Source dataset images are 60×80px thumbnails, so display resolution is intentionally limited.
